from distroduce.configuration.kakfa import configure_producer
from pyspark.context import SparkContext


def distributed_produce(
        sc: SparkContext,
        spark_run,
        sim_time,
        sim_runs,
        rdd_parts,
        parameterized_message,
        prod_config
):

    message_counts = [sim_time] * sim_runs
    msg_rdd = sc.parallelize(message_counts).repartition(rdd_parts)
    parts = msg_rdd.getNumPartitions()
    print()
    print(f"RDD_{spark_run} - Partitions: {parts}")
    print()

    produce = configure_producer(parameterized_message, prod_config)
    return msg_rdd.map(produce).collect()
