from cadCAD.configuration import Experiment

exp = Experiment()