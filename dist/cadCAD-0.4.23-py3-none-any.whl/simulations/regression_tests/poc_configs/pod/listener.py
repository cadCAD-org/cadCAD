import dill, codecs
from flask import request

from simulations.regression_tests.poc_configs.models import exp

# Given job
job = exp.ser_flattened_configs[0]
new_ser_flattened_configs = [job]
spec_configs = list(map(lambda c: dill.loads(c), exp.ser_flattened_configs))

b = request.form['job']
unpickled = dill.loads(codecs.decode(b.encode(), "base64"))


