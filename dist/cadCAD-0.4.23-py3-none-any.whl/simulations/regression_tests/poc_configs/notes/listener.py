from simulations.regression_tests.poc_configs import poc

flattened_dicts = [c.__dict__ for c in poc.configs]


def get_filtered_dict(d):
    newDict = {}
    # Iterate over all the items in dictionary and filter items which has even keys
    for k, v in d.items():
       # Check if key is even then add pair to new dictionary
       if k in ['experiment_id', 'simulation_id', 'run_id']:
           newDict[k] = v
    return newDict


mapped_jobs = []
for i, d in enumerate(flattened_dicts):
    new_d = get_filtered_dict(d)
    new_d['job_id'] = i
    mapped_jobs.append(new_d)

job3 = [j for j in mapped_jobs if j['job_id'] is 3][0]
exec_jobs = list(zip(mapped_jobs, poc.configs))
chosen_job3 = [(job, sys_config) for job, sys_config in exec_jobs if str(job) == str(job3)][0]
selected_config = chosen_job3[1]