import dill

from simulations.regression_tests.poc_configs import poc

pickled_experiment = dill.dumps(poc)
# print(poc.configs)
# print(pickled_experiment)
