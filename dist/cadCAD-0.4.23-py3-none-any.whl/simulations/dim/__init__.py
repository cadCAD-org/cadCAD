from cadCAD.configuration import Experiment

dim_exp = Experiment()