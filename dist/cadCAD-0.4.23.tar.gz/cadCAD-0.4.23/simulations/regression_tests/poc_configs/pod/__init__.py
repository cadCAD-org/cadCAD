import dill
from cadCAD import remote_dict
from simulations.regression_tests.poc_configs.models import config1, config2


def modify_out_metrics(flat_configs):
    sys_job_metrics = {k: v for k, v in flat_configs[0].__dict__.items() if
                       k in ['simulation_id', 'subset_id', 'run_id']}

    sys_job_metrics['sim_id'] = sys_job_metrics.pop('simulation_id')
    sys_job_metrics['run'] = sys_job_metrics.pop('run_id') + 1
    remote_dict['metrics'] = sys_job_metrics


def unpickle_configs(ser_flattened_configs):
    return list(map(lambda c: dill.loads(c), ser_flattened_configs))


def get_unpickled_configs(ser_flattened_configs):
    unpickled_configs = unpickle_configs(ser_flattened_configs)
    modify_out_metrics(unpickled_configs)
    return unpickled_configs
