import pandas as pd
from tabulate import tabulate

from cadCAD.engine import ExecutionMode, ExecutionContext, Executor

from simulations.regression_tests.poc_configs.pod import get_unpickled_configs
from simulations.regression_tests.poc_configs.pod.listener import new_ser_flattened_configs as ser_flattened_configs

configs_lisr_single = get_unpickled_configs(ser_flattened_configs)
exec_mode = ExecutionMode()
local_proc_ctx = ExecutionContext(context=exec_mode.local_mode)
run = Executor(exec_context=local_proc_ctx, configs=configs_lisr_single, empty_return=False) #Option: Disable mem w/

raw_result, tensor_fields, sessions = run.execute()
result = pd.DataFrame(raw_result)
# print(tabulate(tensor_fields[0], headers='keys', tablefmt='psql'))
# pprint(sessions)
# print(tabulate(result, headers='keys', tablefmt='psql'))