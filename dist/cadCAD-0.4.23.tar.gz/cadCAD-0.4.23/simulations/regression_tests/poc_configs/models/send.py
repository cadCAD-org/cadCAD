from pprint import pprint

import requests, dill, codecs

from simulations.regression_tests.poc_configs.models import exp
from simulations.regression_tests.poc_configs.models import config1, config2
import file1
import file2


# http://172.17.0.3:31041/
# endpoints = ['http://0.0.0.0:5001/execute'] * len(exp.ser_flattened_configs)
# endpoints = ['http://172.17.0.3:31920/execute'] * len(exp.ser_flattened_configs)
exp.send(endpoints)
# exp1.send(endpoints)
# exp2.send(endpoints)
# exp3.send(endpoints)
# pprint(exp.ser_flattened_configs)


