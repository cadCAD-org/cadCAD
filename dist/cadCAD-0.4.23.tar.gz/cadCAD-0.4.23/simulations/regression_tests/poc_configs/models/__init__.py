from cadCAD.configuration import Experiment

poc = Experiment()