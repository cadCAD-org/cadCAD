from cadCAD.configuration import Experiment

config1_exp = Experiment()
config2_exp = Experiment()
ext_ds_exp = Experiment()
hist_exp = Experiment()
policy_exp = Experiment()
sweep_exp = Experiment()
udo1_exp = Experiment()
udo2_exp = Experiment()
poc = Experiment()
