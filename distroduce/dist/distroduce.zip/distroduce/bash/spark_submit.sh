#!/bin/bash
spark-submit --master yarn --py-files distroduce.zip messaging_sim.py