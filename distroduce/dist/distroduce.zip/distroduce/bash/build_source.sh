#!/bin/bash
pip3 install -r requirements.txt
#zip -rq dist/distroduce.zip distroduce/
zip -rq distroduce/dist/distroduce.zip distroduce/