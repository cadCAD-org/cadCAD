#!/bin/bash
pip3 install -r requirements.txt
zip -rq distroduce/dist/distroduce.zip distroduce/